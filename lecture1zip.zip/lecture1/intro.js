alert("welcome everyonne")
console.log("ayu")
